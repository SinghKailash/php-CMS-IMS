<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <div class="navbar-toggle collapsed target" data-toggle="collapse" data-target="#navbar">
          <span class="bar1"></span>
          <span class="bar2"></span>
          <span class="bar3"></span>
          <span class="bar4"></span>
        </div>
        <a href="index.php" class="navbar-brand">Hotel Prangan</a>
      </div>
      <nav id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right main-navigation text-uppercase ">
          <li><a href="index.php"><font size="4">Home</font></a></li>
          <li><a href="exchange.php"><font size="4	" color="green">B~Xchange</font></a></li>
          <li><a href="http://www.hotelprangan.in"target="_blank"><font size="4">Hotel</font></a></li>
          <li><a href="logout.php"><font size="4" color="red">Logout</font></a></li>
        </ul>
      </nav>
    </div>
  </div>
