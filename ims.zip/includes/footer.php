<div class="footer navbar-fixed-bottom" id="footer" align="center">

    <div class="copyright p">� 2016 <a href="http://www.oddaka.in">Powered by Oddaka Tech</a></div>
  </div>