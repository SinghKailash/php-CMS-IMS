<div style= "width: 300px;" align = left>
<nav>
    <ul>
      <li><a class="social google" href="invent_mgmt.php">Inventory Management</a></li>
      <li><a class="social tumblr" href="view_bills.php">View Bills</a></li>
      <li><a class="social facebook" href="order.php">Take Orders</a></li>
      <li><a class="social github" href="order.php">View Orders</a></li>
	  <li><a class="social codepen" href="order.php">Edit Orders</a></li>
    </ul>
</nav>
</div>