<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<meta name="generator" content="LibreOffice 4.4.3.2 (Linux)"/>
	<meta name="created" content="00:00:00"/>
	<meta name="changedby" content="ShuSan "/>
	<meta name="changed" content="2016-01-30T14:06:27.484326331"/>
</head>
<body lang="en-IN" dir="ltr">
<p>&lt;?php include(&quot;includes/connection.php&quot;); 
</p>
<p><br/>
<br/>

</p>
<p>$sql=&quot;INSERT INTO bar_hp_inventory (product_id, product_name,
product_category, retail_price, max_price, min_price, quantity,
update_time) VALUES
('$_POST[product_id]','$_POST[product_name]','$_POST[product_category]','$_POST[retail_price]',
'$_POST[max_price]','$_POST[min_price]',
'$_POST[quantity]','$_POST[update_time]' )&quot;; echo &quot;1 record
added&quot;; ?&gt; 
</p>
<p><br/>
<br/>

</p>
<p><br/>
<br/>

</p>
<p><br/>
<br/>

</p>
</body>
</html>